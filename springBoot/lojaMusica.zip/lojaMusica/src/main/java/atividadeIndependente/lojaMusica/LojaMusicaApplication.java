package atividadeIndependente.lojaMusica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaMusicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaMusicaApplication.class, args);
	}

}
