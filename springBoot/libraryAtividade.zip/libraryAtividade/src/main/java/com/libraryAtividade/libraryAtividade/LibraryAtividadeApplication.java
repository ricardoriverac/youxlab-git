package com.libraryAtividade.libraryAtividade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryAtividadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryAtividadeApplication.class, args);
	}

}
