package io.TesteLucas.libraryapi2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Libraryapi2Application {

	public static void main(String[] args) {
		SpringApplication.run(Libraryapi2Application.class, args);
	}

}
