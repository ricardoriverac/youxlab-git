package TesteLoja.AtividadeIdenpendente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeIdenpendenteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeIdenpendenteApplication.class, args);
	}

}
