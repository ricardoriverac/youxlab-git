package io.github.cursodsousa.arquiteturaSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquiteturaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquiteturaSpringApplication.class, args);
	}

}
